public class Usuario
{
    public string Nome { get; set; }
    public string Email { get; set; }
    public long Telefone { get; set; }
}
