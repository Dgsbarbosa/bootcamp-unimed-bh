import { MarcaTextoDirective } from './marca-texto.directive';

describe('MarcaTextoDirective', () => {
  it('should create an instance', () => {
    const directive = new MarcaTextoDirective();
    expect(directive).toBeTruthy();
  });
});
