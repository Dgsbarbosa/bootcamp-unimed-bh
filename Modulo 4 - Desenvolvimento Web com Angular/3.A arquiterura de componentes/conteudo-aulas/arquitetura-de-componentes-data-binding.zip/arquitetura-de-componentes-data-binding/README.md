# Arquitetura de componentes

Projeto desenvolvido para exemplificar os tipos de data binding do Angular.

Para consultar os slides da apresentação, acessar o link: https://drive.google.com/file/d/1Wv4BDj7YXd9mBsvTc-tBACAw0Hb-FN8U/view?usp=sharing

Obrigada pela participação e bons estudos!

Qualquer coisa só dar um salve!

## Redes sociais:

- **Instagram**: https://www.instagram.com/ravenita_/
- **Linkedin**: https://www.linkedin.com/in/geovanasribeiro/
- **Spotify** (pra quem quiser ouvir umas playlists maneiras): https://open.spotify.com/user/22tk6jgofco56wm3rk3ctx6lq?si=7oQp1VrcRRiVQ8nDaPGBWg 