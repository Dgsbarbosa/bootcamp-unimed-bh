import { PrintListPipe } from './print-list.pipe';

describe('PrintListPipe', () => {
  it('create an instance', () => {
    const pipe = new PrintListPipe();
    expect(pipe).toBeTruthy();
  });
});
