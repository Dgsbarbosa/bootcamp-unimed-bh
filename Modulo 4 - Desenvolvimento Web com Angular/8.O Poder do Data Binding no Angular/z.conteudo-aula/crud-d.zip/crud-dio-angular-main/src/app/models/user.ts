export interface User {
  id: number,
  nome: string,
  sobrenome: string,
  idade: number,
  profissao: string,
}
